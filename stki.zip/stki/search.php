<?php
include "index.php";
include "koneksi.php";
?>
<html>
	<form action='searchs.php' method='GET'>
    	  <center> 
			    <img src="assets/images/20201101_160552.png" alt="Google Title">
            <br><input type='text' size='50' name='keyword'> <input type='submit' value='Cari'></font></p>
   
      </center>
      </form>
</html>